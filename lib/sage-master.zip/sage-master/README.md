# sage
SAGE Version 6.1 SDK Usage 
Link: https://smist08.wordpress.com/2013/01/01/the-sage-300-erp-java-api/
