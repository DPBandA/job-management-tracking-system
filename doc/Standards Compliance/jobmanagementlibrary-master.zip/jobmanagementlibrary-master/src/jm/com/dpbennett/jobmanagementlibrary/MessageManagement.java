/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jm.com.dpbennett.jobmanagementlibrary;

/**
 *
 * @author dbennett
 */
public interface MessageManagement {

    public String getInvalidFormFieldMessage();

    public void setInvalidFormFieldMessage(String invalidFormFieldMessage);
}
